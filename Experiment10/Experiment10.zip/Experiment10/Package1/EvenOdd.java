package Experiment10.Package1;

public class EvenOdd {
    public void show(int a) {
        if (a % 2 == 0)
            System.out.println("The number is even");
        else
            System.out.println("The number is odd");
    }
}
